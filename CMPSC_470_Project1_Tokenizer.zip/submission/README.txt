Name:		Tyler Lindsay
Email:  	tylerl@psu.edu
Class:  	CMPSC 470, Compilers
Instructor: 	Dr. Hyuntae Na

COMPILATION INSTRUCTIONS

Compile modified Lexer.java, Parser.java, and DoubleBuffer.java files along with standard ParserVal.java, Compiler.java, and Program.java files. Run the Program class on *.minc files as outlined in the project description.